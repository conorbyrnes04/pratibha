# pratibhā brand assets

Flat vector/PNG, no foil, no paper texture. Field #090912 · Parchment #f6efe4 · Gold #d8a84a / bright #f0c979 · Vermillion #b85b3d · Lapis #324867.
Wordmark is Latin `pratibhā` only on the icon, favicon, and header — devanāgarī (प्रतिभा) appears only as an explored sticker-front option, never on those three.

This folder has two parts:
- **the confirmed set** (wordmark/, icon/, social/, print/, source/) — same files as before, ready to drop into the repo per the table below.
- **variants/** — every alternate direction explored in review, not yet picked. Nothing in variants/ is wired into the confirmed set; move a file up and rename it once you decide.

## wordmark/
| file | use |
|---|---|
| `wordmark.svg` | vector wordmark, gold on transparent |
| `wordmark-dark-ink.svg` | vector wordmark, dark ink on transparent (light backgrounds) |
| `wordmark-on-dark.png` | 2400×800, flattened, for dark-field placements |
| `wordmark-on-light.png` | 2400×800, transparent bg, dark ink, for light-field placements |
| `lockup-yantra-left.svg` | seal + pratibhā + "LIVING MANUSCRIPT" — **this is the live header** |

## icon/
| file | repo destination |
|---|---|
| `seal.svg` | source vector, 8-petal seal (not the square bhupura) |
| `seal-mono-white.svg` | white-on-transparent seal, for monochrome/tint contexts |
| `icon-1024.png` | `mobile/assets/images/icon.png` (iOS / Expo) |
| `splash-1024.png` | `mobile/assets/images/splash-icon.png` (on #090912) |
| `android-icon-foreground.png` | `android-icon-foreground.png` — safe in center 66% |
| `android-icon-monochrome.png` | `android-icon-monochrome.png` — white on transparent |
| `favicon-32.png` | `favicon-32.png` |
| `favicon-48.png` | `favicon-48.png` |
| `icon-192.png` | `icon-192.png` |
| `apple-touch-180.png` | `apple-touch-180.png` |

Checked at 16px — reads clean.

## social/
| file | use |
|---|---|
| `og-1200x630.png` | yantra + pratibhā + "Living Manuscript" on #090912, for OG/Twitter cards |

## print/
| file | use |
|---|---|
| `sticker-front-3in-600dpi.png` | 1800×1800 circle, full yantra + pratibhā wordmark |
| `sticker-back-qr-3in-600dpi.png` | 1800×1800 circle, QR → pratibha.agniagama.com (utm_source=sticker&utm_medium=qr&utm_campaign=first_users) |

## source/
| file | use |
|---|---|
| `yantra-mark-transparent.png` | 1024×1024 full yantra, background keyed to transparent, for building new compositions |

## variants/wordmark/ — alternate treatments of "pratibhā", not yet picked
All Cormorant Garamond italic 600 with custom accents (bindu/macron/seal drawn on top) — not redrawn letterforms. On #090912 field.
| file | id | description |
|---|---|---|
| `3a-bright-bindu-drawn-macron.png` | 3a | bright-gold bindu + a drawn macron bar over the ā |
| `3b-two-tone.png` | 3b | "prati" gold, "bhā" parchment, vermillion bindu |
| `3c-seal-i-dot.png` | 3c | the 8-petal seal itself stands in for the ı-dot |
| `3d-rule-bindu-tagline.png` | 3d | wordmark + hairline rule/bindu divider + "LIVING MANUSCRIPT" as one lockup |
| `3e-engraved-outline.png` | 3e | hollow/engraved outline letters, gold stroke only |
| `3f-flat-gold-fill.png` | 3f | flat two-step gold gradient fill, parchment bindu |
| `4a-fused-seal-dot-two-tone.png` | 4a | 3b + 3c fused: seal as the i-dot (lowered), two-tone prati/bhā |
| `4b-fused-hollowed.png` | 4b | same fusion, hollowed/engraved like 3e |
| `5a`–`5g` `-with-tagline-*.png` | 5a–5g | each of 3a/3b/3c/3e/3f/4a/4b repeated with the 3d rule+bindu divider and "LIVING MANUSCRIPT" set underneath |

## variants/icon/ — app icon / seal placement and field options, not yet picked
Shown at the 360px tier, before crop to the actual icon sizes.
| file | id | description |
|---|---|---|
| `3g-full-yantra-on-field.png` | 3g | full yantra (all bhupura gates), 84% scale, on field — noisy at 32px |
| `3h-full-yantra-cropped.png` | 3h | full yantra bleed-cropped tight to the lotus ring — survives small sizes better |
| `3i-seal-on-field.png` | 3i | 8-petal seal only, on field — **this is the confirmed icon/ above** |
| `3j-seal-on-parchment.png` | 3j | seal on parchment field |
| `3k-seal-mono-on-vermillion.png` | 3k | mono-white seal on vermillion field |
| `3l-seal-on-lapis.png` | 3l | seal on lapis field |

## variants/sticker-font/ — sticker-front type options, not yet picked
Full 1800×1800 sticker-front comps with the full yantra; only the wordmark type changes.
| file | id | description |
|---|---|---|
| `2a-cormorant-garamond.png` | 2a | Cormorant Garamond italic — current |
| `2b-eb-garamond.png` | 2b | EB Garamond italic — sturdier hairlines for print |
| `2c-cardo.png` | 2c | Cardo italic |
| `2d-spectral.png` | 2d | Spectral italic |
| `2e-devanagari-tiro.png` | 2e | प्रतिभा in Tiro Devanagari Sanskrit, scholarly/letterpress feel |
| `2f-devanagari-rozha-one.png` | 2f | प्रतिभा in Rozha One, bold display |
| `2g-devanagari-martel.png` | 2g | प्रतिभा in Martel 600 |
| `2h-devanagari-yatra-one.png` | 2h | प्रतिभा in Yatra One |

Note: the devanāgarī options (2e–2h) are for the sticker only, per the brief — never the icon, favicon, or header.
